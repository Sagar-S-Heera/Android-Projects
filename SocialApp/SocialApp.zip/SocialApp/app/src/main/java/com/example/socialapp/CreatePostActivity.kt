package com.example.socialapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.socialapp.doas.PostDao

class CreatePostActivity : AppCompatActivity() {

    private lateinit var postDao: PostDao
    lateinit var postButton: Button
    lateinit var postInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_post)

        postDao = PostDao()

        postInput = findViewById(R.id.postInput)
        postButton = findViewById(R.id.postButton)
        postButton.setOnClickListener {
            val input = postInput.text.toString().trim()
            if (input.isNotEmpty()) {
                postDao.addPost(input)
                Toast.makeText(this, "Post Created!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}