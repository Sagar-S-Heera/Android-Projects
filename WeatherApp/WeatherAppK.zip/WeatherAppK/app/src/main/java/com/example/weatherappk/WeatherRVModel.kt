package com.example.weatherappk

data class WeatherRVModel(
    val time: String,
    val temp: String,
    val icon: String,
    val windSpeed: String
)