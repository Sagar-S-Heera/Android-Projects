package com.example.weatherappk

import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.squareup.picasso.Picasso
import org.json.JSONException
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var fusedLocationProvider: FusedLocationProviderClient
    private lateinit var homeRl: RelativeLayout
    private lateinit var loadingPB: ProgressBar
    private lateinit var cityNameTV: TextView
    private lateinit var temperatureTV: TextView
    private lateinit var conditionTV: TextView
    private lateinit var cityEdt: EditText
    private lateinit var backIV: ImageView
    private lateinit var iconIV: ImageView
    private lateinit var searchIV: ImageView
    private lateinit var weatherRV: RecyclerView

    private lateinit var weatherRVModelArrayList: ArrayList<WeatherRVModel>
    private var weatherRVAdapter: WeatherRVAdapter? = null
    private var locationManager: LocationManager? = null
    private val PERMISSION_CODE: Int = 1
    private var cityName: String? = null

    private var linearLayoutManager: LinearLayoutManager? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationProvider = LocationServices.getFusedLocationProviderClient(this)

        //fullScreen app
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )


        homeRl = findViewById(R.id.idRLHome)
        loadingPB = findViewById(R.id.idPBLoading)
        cityNameTV = findViewById(R.id.idTVCityName)
        temperatureTV = findViewById(R.id.idTVTemp)
        conditionTV = findViewById(R.id.idTVCondition)
        cityEdt = findViewById(R.id.idEdtCity)

        weatherRV = findViewById(R.id.idRVWeather)
        searchIV = findViewById(R.id.idIVSearch)
        iconIV = findViewById(R.id.idIVIcon)
        backIV = findViewById(R.id.idIVBack)

        weatherRVModelArrayList = ArrayList()
        linearLayoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        weatherRVAdapter = WeatherRVAdapter(this, weatherRVModelArrayList)
        weatherRV.adapter = weatherRVAdapter
        weatherRV.layoutManager = linearLayoutManager

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        //checking whether the location permissions are granted are not
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this@MainActivity,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                PERMISSION_CODE
            )
        }
        val location = locationManager!!.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        if (location != null) {
            cityName = getCityName(location.longitude, location.latitude)
            cityName?.let { getWeatherInfo(it) }
        } else {
            getWeatherInfo("Bangalore")
        }
        searchIV.setOnClickListener {
            val city = cityEdt.text.toString()
            if (city.isEmpty()) {
                Toast.makeText(this@MainActivity, "Please enter city name", Toast.LENGTH_SHORT)
                    .show()
                cityNameTV.text = "CITY NAME"
            } else {
                cityNameTV.text = city
                getWeatherInfo(city)
            }
        }
    }
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String?>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permissions Granted.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please provide the permission.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun getCityName(longitude: Double, latitude: Double): String? {
        var cityName: String? = "Not Found"
        val gcd = Geocoder(baseContext, Locale.getDefault())
        try {
            val addresses = gcd.getFromLocation(latitude, longitude, 10)
            for (add in addresses) {
                if (add != null) {
                    val city = add.locality
                    if (city != null && city != "") cityName = city else Toast.makeText(
                        this,
                        "Cannot find location",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return cityName
    }

    private fun getWeatherInfo(cityName: String) {
        val url =
            "http://api.weatherapi.com/v1/forecast.json?key=06c18539f49f47ec9d8135656222710&q=$cityName&days=1&aqi=no&alerts=no"
        cityNameTV.text = cityName
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                loadingPB.visibility = View.GONE
                homeRl.visibility = View.VISIBLE
                weatherRVModelArrayList.clear()
                //Toast.makeText(this, "working", Toast.LENGTH_SHORT).show()
                try {
                    val curTemp = response.getJSONObject("current").getString("temp_c")
                    temperatureTV.text = "$curTemp°C"
                    val condition = response.getJSONObject("current").getJSONObject("condition")
                        .getString("text")
                    conditionTV.text = condition
                    val conditionIcon = response.getJSONObject("current").getJSONObject("condition")
                        .getString("icon")
                    Picasso.get().load("http:$conditionIcon").into(iconIV)
                    val isDay = response.getJSONObject("current").getInt("is_day")
                    if (isDay == 1)
                        Picasso.get().load("https://wallpaperaccess.com/full/3162177.jpg")
                            .into(backIV)
                    else
                        Picasso.get().load("https://wallpaperaccess.com/full/148508.jpg")
                            .into(backIV)

                    val forecastObj = response.getJSONObject("forecast").getJSONArray("forecastday")
                        .getJSONObject(0)
                    val hrs = forecastObj.getJSONArray("hour")
                    var i = 0
                    while (i < hrs.length()) {
                        val hrObj = hrs.getJSONObject(i)
                        val time = hrObj.getString("time")
                        val temper = hrObj.getString("temp_c")
                        val img = hrObj.getJSONObject("condition").getString("icon")
                        val wind = hrObj.getString("wind_kph")
                        weatherRVModelArrayList.add(WeatherRVModel(time, temper, img, wind))
                        i++
                    }
                    weatherRVAdapter!!.notifyDataSetChanged()
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }
        ) {
            Toast.makeText(this@MainActivity, "Enter valid city name", Toast.LENGTH_SHORT).show()
        }
        MySingleton.getInstance(this).requestQueue.add(jsonObjectRequest)
    }
}