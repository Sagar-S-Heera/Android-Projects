package com.example.weatherappk

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import java.text.SimpleDateFormat

class WeatherRVAdapter(val context: Context,val weatherRVModelArrayList: ArrayList<WeatherRVModel>) :
    RecyclerView.Adapter<WeatherRVAdapter.MyViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        //this is where u inflate the layout(giving a look to our rows i.e., items)
        val view = LayoutInflater.from(context).inflate(R.layout.weather_rv_item, parent, false)
        view.layoutParams = ViewGroup.LayoutParams(
            (parent.width * 0.5).toInt(),
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        //binding process happens here
        //assigning values to the views we created in the weather_rv_item layout file
        //based on the position of the recycler view
        //Toast.makeText(context,"working",Toast.LENGTH_SHORT).show()
        val model = weatherRVModelArrayList!![position]
        holder.tempTV.text = model.temp + "°C"
        Picasso.get().load("http:" + model.icon).into(holder.conditionIV)
        holder.windTV.text = model.windSpeed + "Km/h"
        val input = SimpleDateFormat("yyyy-MM-dd hh:mm")
        val output = SimpleDateFormat("hh:mm aa")
        try {
            val t = input.parse(model.time)
            holder.timeTV.text = output.format(t)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        //recycler view wants to know the number of items u want to display.
        return weatherRVModelArrayList!!.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        //grabbing the views from the weather_rv_item layout file n assigning them
         val windTV: TextView
         val tempTV: TextView
         val timeTV: TextView
         val conditionIV: ImageView

        init {
            windTV = itemView.findViewById(R.id.idTVWindSpeed)
            tempTV = itemView.findViewById(R.id.idTVTemperature)
            timeTV = itemView.findViewById(R.id.idTVTime)
            conditionIV = itemView.findViewById(R.id.idIVCondition)
        }
    }
}